<?php

namespace App\Http\Livewire;

use App\Models\Offers;
use Illuminate\Support\Carbon;
use Illuminate\Database\Eloquent\Builder;
use PowerComponents\LivewirePowerGrid\Rules\{Rule, RuleActions};
use PowerComponents\LivewirePowerGrid\Traits\ActionButton;
use PowerComponents\LivewirePowerGrid\{Button, Column, Exportable, Footer, Header, PowerGrid, PowerGridComponent, PowerGridEloquent};

final class OffersTable extends PowerGridComponent
{
    use ActionButton;

    /*
    |--------------------------------------------------------------------------
    |  Features Setup
    |--------------------------------------------------------------------------
    | Setup Table's general features
    |
    */
    public function setUp(): void
    {
        $this->showCheckBox() //Adds checkboxes to each table row
            ->showRecordCount() //Display: Showing 1 to 10 of 20 Results
            ->showPerPage() //Shows per page option
            ->showSearchInput() //Show search input on page top.
            ->showExportOption('download', ['excel', 'csv']); //Enables export feature and show button on page top.
    }

    /*
    |--------------------------------------------------------------------------
    |  Datasource
    |--------------------------------------------------------------------------
    | Provides data to your Table using a Model or Collection
    |
    */

    /**
    * PowerGrid datasource.
    *
    * @return Builder<\App\Models\Offers>
    */
    public function datasource(): Builder
    {
        return Offers::query();
    }

    /*
    |--------------------------------------------------------------------------
    |  Relationship Search
    |--------------------------------------------------------------------------
    | Configure here relationships to be used by the Search and Table Filters.
    |
    */

    /**
     * Relationship search.
     *
     * @return array<string, array<int, string>>
     */
    public function relationSearch(): array
    {
        return [];
    }

    /*
    |--------------------------------------------------------------------------
    |  Add Column
    |--------------------------------------------------------------------------
    | Make Datasource fields available to be used as columns.
    | You can pass a closure to transform/modify the data.
    |
    | ❗ IMPORTANT: When using closures, you must escape any value coming from
    |    the database using the `e()` Laravel Helper function.
    |
    */
    public function addColumns(): PowerGridEloquent
    {
        return PowerGrid::eloquent()
            ->addColumn('id')
            ->addColumn('title')

           /** Example of custom column using a closure **/
            ->addColumn('title_lower', function (Offers $model) {
                return strtolower(e($model->title));
            })

            //->addColumn('description')
            ->addColumn('description', function (Offers $model) {
                return implode(",", $model->description);
            })
            ->addColumn('materials', function (Offers $model) {
                $string = '<select style="border:none">';
                foreach($model->materials as $material){
                    $string =  $string.'<option value="">'.$material->name.'</option>';
                }
                $string =  $string.'</select>';
                return $string;
            })
            ->addColumn('submaterials', function (Offers $model) {
                $string = '<select style="border:none">';
                foreach($model->submaterials as $submaterial){
                    $string =  $string.'<option value="">'.$submaterial->name.'</option>';
                }
                $string =  $string.'</select>';
                return $string;
            })
            ->addColumn('tags', function (Offers $model) {
                $string = '<select style="border:none">';
                foreach($model->tags as $tag){
                    $string =  $string.'<option value="">'.$tag->name.'</option>';
                }
                $string =  $string.'</select>';
                return $string;
            })
            ->addColumn('user_id')
            ->addColumn('categories_id')
            ->addColumn('approaches_id')
            ->addColumn('url')
            ->addColumn('contact')
            ->addColumn('job')
            ->addColumn('status')
            ->addColumn('created_at_formatted', fn (Offers $model) => Carbon::parse($model->created_at)->format('d/m/Y H:i:s'))
            ->addColumn('updated_at_formatted', fn (Offers $model) => Carbon::parse($model->updated_at)->format('d/m/Y H:i:s'));
    }

    /*
    |--------------------------------------------------------------------------
    |  Include Columns
    |--------------------------------------------------------------------------
    | Include the columns added columns, making them visible on the Table.
    | Each column can be configured with properties, filters, actions...
    |
    */

     /**
     * PowerGrid Columns.
     *
     * @return array<int, Column>
     */
    public function columns(): array
    {
        return [
            Column::make('ID', 'id')
                ->makeInputRange(),

            Column::make('TITLE', 'title')
                ->sortable()
                ->searchable()
                ->makeInputText(),

            Column::make('DESCRIPTION', 'description')
                ->sortable()
                ->searchable(),

            Column::make('MATERIALS', 'materials')
                ->sortable()
                ->searchable(),

            Column::make('SUBMATERIALS', 'submaterials')
                ->sortable()
                ->searchable(),

            Column::make('TAGS', 'tags')
                ->sortable()
                ->searchable(),

            Column::make('USER ID', 'user_id')
                ->makeInputRange(),

            Column::make('CATEGORIES ID', 'categories_id')
                ->makeInputRange(),

            Column::make('APPROACHES ID', 'approaches_id')
                ->makeInputRange(),

            Column::make('URL', 'url')
                ->sortable()
                ->searchable()
                ->makeInputText(),

            Column::make('CONTACT', 'contact')
                ->sortable()
                ->searchable()
                ->makeInputText(),

            Column::make('JOB', 'job')
                ->sortable()
                ->searchable()
                ->makeInputText(),

            Column::make('STATUS', 'status')
                ->sortable()
                ->searchable()
                ->makeInputText(),

            Column::make('CREATED AT', 'created_at_formatted', 'created_at')
                ->searchable()
                ->sortable()
                ->makeInputDatePicker(),

            Column::make('UPDATED AT', 'updated_at_formatted', 'updated_at')
                ->searchable()
                ->sortable()
                ->makeInputDatePicker(),

        ]
;
    }

    /*
    |--------------------------------------------------------------------------
    | Actions Method
    |--------------------------------------------------------------------------
    | Enable the method below only if the Routes below are defined in your app.
    |
    */

     /**
     * PowerGrid Offers Action Buttons.
     *
     * @return array<int, Button>
     */

    /*
    public function actions(): array
    {
       return [
           Button::make('edit', 'Edit')
               ->class('bg-indigo-500 cursor-pointer text-white px-3 py-2.5 m-1 rounded text-sm')
               ->route('offers.edit', ['offers' => 'id']),

           Button::make('destroy', 'Delete')
               ->class('bg-red-500 cursor-pointer text-white px-3 py-2 m-1 rounded text-sm')
               ->route('offers.destroy', ['offers' => 'id'])
               ->method('delete')
        ];
    }
    */

    /*
    |--------------------------------------------------------------------------
    | Actions Rules
    |--------------------------------------------------------------------------
    | Enable the method below to configure Rules for your Table and Action Buttons.
    |
    */

     /**
     * PowerGrid Offers Action Rules.
     *
     * @return array<int, RuleActions>
     */

    /*
    public function actionRules(): array
    {
       return [

           //Hide button edit for ID 1
            Rule::button('edit')
                ->when(fn($offers) => $offers->id === 1)
                ->hide(),
        ];
    }
    */
}
