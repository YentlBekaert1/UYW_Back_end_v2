<?php $attributes = $attributes->exceptProps([
    'row' => null,
    'field' => null,
    'enabled' => null,
    'label' => null
]); ?>
<?php foreach (array_filter(([
    'row' => null,
    'field' => null,
    'enabled' => null,
    'label' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div x-data="{ value: '<?php echo e($field); ?>'}">
    <?php if($enabled): ?>
        <button
            style="background: transparent; text-align: left;border: 0;padding: 4px;"
            x-on:click="$pgClipboard(value)"
            title="<?php echo e($label); ?>">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'livewire-powergrid::components.icons.copy','data' => []]); ?>
<?php $component->withName('livewire-powergrid::icons.copy'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </button>
    <?php endif; ?>
</div>
<?php /**PATH H:\H_Projectjes\backendUYWV3\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/click-to-copy.blade.php ENDPATH**/ ?>