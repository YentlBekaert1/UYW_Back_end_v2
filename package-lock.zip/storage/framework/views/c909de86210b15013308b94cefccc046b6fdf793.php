<?php $attributes = $attributes->exceptProps([
    'theme' => '',
    'column' => null,
    'class' => '',
    'inline' => null,
    'booleanFilter' => null,
]); ?>
<?php foreach (array_filter(([
    'theme' => '',
    'column' => null,
    'class' => '',
    'inline' => null,
    'booleanFilter' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <?php if(filled($booleanFilter)): ?>
        <div class="<?php if($inline): ?> <?php echo e($theme->divClassInline); ?> <?php endif; ?> <?php echo e($theme->divClassNotInline); ?><?php echo ($booleanFilter['class'] != '') ?? ''; ?>">
            <?php if(!$inline): ?>
                <label class="text-gray-700 dark:text-gray-300"
                       for="input_boolean_filter_<?php echo e(data_get($booleanFilter, 'field')); ?>">
                    <?php echo e(data_get($booleanFilter, 'label')); ?>

                </label>
            <?php endif; ?>
            <div class="relative">
                <select id="input_boolean_filter_<?php echo e(data_get($booleanFilter, 'field')); ?>"
                        style="<?php echo e(data_get($column, 'headerStyle')); ?>"
                        class="power_grid <?php echo e($theme->inputClass); ?> <?php echo e($class); ?> <?php echo e(data_get($column, 'headerClass')); ?>"
                        wire:input.lazy="filterBoolean('<?php echo e($booleanFilter['dataField']); ?>', $event.target.value, '<?php echo e($booleanFilter['label']); ?>')"
                        wire:model="filters.boolean.<?php echo e($booleanFilter['dataField']); ?>">
                    <option value="all"><?php echo e(trans('livewire-powergrid::datatable.boolean_filter.all')); ?></option>
                    <option value="true"><?php echo e(data_get($booleanFilter, 'true_label')); ?></option>
                    <option value="false"><?php echo e(data_get($booleanFilter, 'false_label')); ?></option>
                </select>
                <div class="<?php echo e($theme->relativeDivClass); ?>">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'livewire-powergrid::components.icons.down','data' => ['class' => 'w-4 h-4']]); ?>
<?php $component->withName('livewire-powergrid::icons.down'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH H:\H_Projectjes\backendUYWV3\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/filters/boolean-filter.blade.php ENDPATH**/ ?>