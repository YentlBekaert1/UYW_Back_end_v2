<?php $attributes = $attributes->exceptProps([
    'theme' => '',
    'class' => '',
    'column' => null,
    'inline' => null,
    'select' => null
]); ?>
<?php foreach (array_filter(([
    'theme' => '',
    'class' => '',
    'column' => null,
    'inline' => null,
    'select' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>

    <?php if(filled($select)): ?>
        <div class="<?php if(!$inline): ?> pt-2 p-2 <?php endif; ?>">
            <?php if(!$inline): ?>
                <label for="input_<?php echo e(data_get($select, 'dataField')); ?>" class="text-gray-700 dark:text-gray-300"><?php echo e(data_get($select, 'label')); ?></label>
            <?php endif; ?>
            <div class="relative">
                <select id="input_<?php echo data_get($select, 'displayField'); ?>"
                        class="power_grid <?php echo e($theme->inputClass); ?> <?php echo e($class); ?> <?php echo e(data_get($column, 'headerClass')); ?>"
                        style="<?php echo e(data_get($column, 'headerStyle')); ?>"
                        wire:input.debounce.500ms="filterSelect('<?php echo e(data_get($select, 'dataField')); ?>','<?php echo e(data_get($select, 'label')); ?>')"
                        wire:model.debounce.500ms="filters.select.<?php echo e(data_get($select, 'dataField')); ?>"
                        data-live-search="true">
                    <option value=""><?php echo e(trans('livewire-powergrid::datatable.select.all')); ?></option>
                    <?php $__currentLoopData = data_get($select, 'data_source'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $key = isset($relation['id']) ? 'id' : 'value';
                            if (isset($relation[$select['dataField']])) $key = $select['dataField'];
                        ?>
                        <option value="<?php echo e(data_get($relation, $key)); ?>">
                            <?php echo e($relation[data_get($select, 'displayField') ]); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="<?php echo e($theme->relativeDivClass); ?>">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'livewire-powergrid::components.icons.down','data' => ['class' => 'w-4 h-4']]); ?>
<?php $component->withName('livewire-powergrid::icons.down'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

</div>
<?php /**PATH H:\H_Projectjes\backendUYWV3\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/filters/select.blade.php ENDPATH**/ ?>