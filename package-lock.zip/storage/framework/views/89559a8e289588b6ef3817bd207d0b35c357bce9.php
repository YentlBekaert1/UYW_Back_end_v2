<?php $helperClass = app('PowerComponents\LivewirePowerGrid\Helpers\Helpers'); ?>
<?php $attributes = $attributes->exceptProps([
    'primaryKey' => null,
    'row' => null,
    'field' => null,
    'theme' => null,
    'currentTable' => null,
    'tableName' => null,
]); ?>
<?php foreach (array_filter(([
    'primaryKey' => null,
    'row' => null,
    'field' => null,
    'theme' => null,
    'currentTable' => null,
    'tableName' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div x-cloak
     x-data="pgEditable({
       tableName: '<?php echo e($tableName); ?>',
       id: '<?php echo e($row->{$primaryKey}); ?>',
       dataField: '<?php echo e($field); ?>',
       content: '<?php echo e($helperClass->resolveContent($currentTable, $field, $row)); ?>'
     })">
    <div x-html="content"
         style="border-bottom: dotted 1px; cursor: pointer"
         x-show="!editable"
         x-on:click="editable = true"
    ></div>
    <div x-show="editable">
        <input
            type="text"
            x-on:keydown.enter="save()"
            :class="{'cursor-pointer': !editable}"
            class="<?php echo e($theme->inputClass); ?> p-2"
            x-ref="editable"
            x-text="content"
            :value="$root.firstElementChild.innerText">
    </div>
</div>
<?php /**PATH H:\H_Projectjes\backendUYWV3\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/editable.blade.php ENDPATH**/ ?>