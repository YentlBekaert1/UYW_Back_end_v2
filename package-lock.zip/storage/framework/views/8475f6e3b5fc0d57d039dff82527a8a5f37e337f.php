<div wire:loading class="mt-2">
    <div class="loader ease-linear rounded-full border-2 border-t-2 border-gray-200 h-6 w-6"></div>
</div>
<?php /**PATH H:\H_Projectjes\backendUYWV3\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/frameworks/tailwind/loading.blade.php ENDPATH**/ ?>