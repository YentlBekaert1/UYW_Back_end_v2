<?php return array (
  'power-grid-demo-table' => 'App\\Http\\Livewire\\PowerGridDemoTable',
);